SMOKEY VOX 1.7.0 (build 42) - Windows 64-bit VST3

1. Close your DAW.
2. Copy the whole "Septet.vst3" folder into:
   C:\Program Files\Common Files\VST3
   (Windows will ask for administrator permission.)
3. Open your DAW and rescan plug-ins. In Ableton Live: Settings > Plug-Ins, switch on "Use VST3 Plug-In System Folders", then Rescan.
4. It appears as SMOKEY VOX under Cosby Audio.

The folder keeps the name Septet so later versions replace it in place.
This version does not update itself on Windows: download the next one from the same page.
